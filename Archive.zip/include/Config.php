<?php
/**
 * Database configuration
 */
//local
define('DB_HOST', '127.0.0.1');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 's4ittech@123');
define('DB_NAME', 'mvs');

//live
//define('DB_HOST', 'localhost');
//define('DB_USERNAME', 'vsadmin');
//define('DB_PASSWORD', 'za8zKY8FXT8WSsYH');
//define('DB_NAME', 'vsadmin');

define('USER_CREATED_SUCCESSFULLY', 0);
define('USER_CREATE_FAILED', 1);
define('USER_ALREADY_EXISTED', 2);
?>
